<!DOCTYPE html>
<html lang="en">
<head>
<title>SYLVESTER'S SALON</title>
    
    <?php
    include 'fragments/util-top.html';
    ?>
</head>
    
<body>
<?php
    include 'fragments/header.html';
    ?>
	
	 <?php
                            $user =  'epal123'; // change to user cookie
                            require 'fragments/db.php';
                            $query = "SELECT * FROM transaction WHERE cust_name = '".$user."'"; // change for database

                            $result = mysqli_query($db2, $query);
                            if ($result = mysqli_query($db2, $query)){
                                while ($row = mysqli_fetch_row($result)){
                                    printf ("<div class = 'container' >
                                    <p>Service Type: %s</p> <p>Description: %s</p> <p>Date: %s</p>  <p>%s</p></div>", $row[0], $row[1], $row[2], $row[3]);
                                }
                                
                    mysqli_free_result($result);
                            }
                            else{
                                echo "<h3>no previous transactions</h2>";
                            }
                            ?>
        

    <?php
    include 'fragments/footer.html';
    ?>            
	
    <?php
    include 'fragments/util-bot.html';
    ?> 
	
</body>
</html>
    