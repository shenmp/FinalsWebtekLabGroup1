<!DOCTYPE html>
<html lang="en">
<head>
<title>SYLVESTER'S SALON</title>
    
    <?php
    include 'fragments/util-top.html';
    ?>
</head>
    
<body>
<?php
    include 'fragments/header.html';
    ?>
	
	
    <!--  about-page -->
	<div class="about">
		<div class="container"> 
			<h3 class="w3ls-title w3ls-title1">About Sylvester's Salon</h3>
			<div class="about-text">	
				<p>We think of ourselves as the protectors of the beauty industry and we take our mission seriously. Passionate about, not just our success, but yours! Personal growth and development is an ongoing experience and at Sylvester's Salon Services we believe in Encouraging Personal Mastery. We offer support and training to help you meet your goals, with unlimited opportunity to move and grow inside the organized; this is a company you can call home.
<br>
                    <br>
                        We mean it when we say we’re not like any other wholesale Beauty company you might know. Transparency and straight talk are required. Titles, hierarchy, and closed-door office space aren’t interesting to us. We leave the egos outside, and we all roll up our sleeves to get things done. Then, we know how to celebrate when we finish.

                        Working at Sylvester's Salon Services & Supplies means living the values that shape our very unique culture. </p> 
				<div class="col-md-3 ftr-top-left about-text-grids">
					<i class="fa fa-shopping-basket" aria-hidden="true"></i>
					<h4>10 <br>Service Providers</h4>
				</div>
				<div class="col-md-3 ftr-top-left about-text-grids">
					<i class="fa fa-users" aria-hidden="true"></i>
					<h4>500 <br>Customers </h4>
				</div>
				<div class="col-md-3 ftr-top-left about-text-grids">
					<i class="fa fa-credit-card" aria-hidden="true"></i>
					<h4>100 <br>Giveaways</h4>
				</div>
				<div class="col-md-3 ftr-top-left about-text-grids">
					<i class="fa fa-globe" aria-hidden="true"></i>
					<h4>20+ <br>Cities</h4>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="history">
				<h3 class="w3ls-title">Our Vission</h3>
				<p>Sylvester's Salon Services builds relationships that create success, by shaping and leading the beauty industry through encouraging personal mastery..</p> 
				<h3 class="w3ls-title">Our Manifesto</h3>
				<p>People are Sylvester's Salon Services’ most important and valuable resource. Each of us is an authentic individual brought together by a common bond: our desire to build long lasting relationships with our customers and each other.  We value integrity, positive energy, teamwork, dedication, communication, responsiveness and action. We are committed in our desire to lead with knowledge and serve with purpose.  We function in an abundant spirit that enriches lives and creates a legacy of excellence.  We cherish the diversity that strengthens the fabric of expression and the freedom to risk through innovation. We are dedicated to the pursuit of lifelong learning through Encouraging Personal Mastery.
                        <b>We are the protectors of the professional beauty industry.</b></p> 
			</div>
		</div>
	</div>
	<!-- //about-page --> 
    

        <?php
    include 'fragments/footer.html';
    ?>            
	
    <?php
    include 'fragments/util-bot.html';
    ?> 
	
</body>
</html>
    