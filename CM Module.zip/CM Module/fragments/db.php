<?php
$db = mysqli_connect('localhost', 'root', 'root', 'salon');
if (!$db) {
    die('error connecting to database');
}
echo 'you have connected successfully';