<!DOCTYPE html>
<html lang="en">
<head>
<title>SYLVESTER'S SALON</title>
    
    <?php
    include 'fragments/util-top.html';
    ?>
</head>
    
<body>
<?php
    include 'fragments/header.html';
    ?>
	
	

<?php
    include 'fragments/footer.html';
    ?>            
	
    <?php
    include 'fragments/util-bot.html';
    ?> 
	
</body>
</html>
    