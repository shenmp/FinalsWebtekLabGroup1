<!DOCTYPE html>
<html lang="en">
<head>
<title>SYLVESTER'S SALON</title>
    
    <?php
    include 'fragments/util-top.html';
    ?>
</head>
    
<body>
<?php
    include 'fragments/header.html';
    ?>
	
	<?php
    require("fragments/db.php");
    
?>
<?php
    $query = "
        SELECT
            cust_id,
            cust_uname,
            Concat(cust_lastname, , cust_firstname),
            cust_address,
            cust_contactno
        FROM customer
         WHERE cust_id = ".$_SESSION['customer']['id']."
    ";

    try
    {
        $stmt = $db->prepare($query);
        $stmt->execute();
    }
    catch(PDOException $ex)
    {
        die("Failed to run query: " . $ex->getMessage());
    }
    $rows = $stmt->fetchAll();
?>
<h1>Hello!! </h1>
<table border='1'>
    <tr>
        <th>User</th>
        <th>Name</th>
        <th>Address</th>
        <th>Contact No</th>
        
    </tr>
    <?php foreach($rows as $row): ?>
        <tr>
            <td><?php echo htmlentities($row['cust_uname'], ENT_QUOTES, 'UTF-8'); ?></td>
            <td><?php echo htmlentities($row['Concat(cust_lastname, , cust_firstname)'], ENT_QUOTES, 'UTF-8'); ?></td>
            <td><?php echo htmlentities($row['cust_address'], ENT_QUOTES, 'UTF-8'); ?></td>
            <td><?php echo htmlentities($row['cust_contactno'], ENT_QUOTES, 'UTF-8'); ?></td>

        </tr>
    <?php endforeach; ?>
</table><br />
    
    
<?php
    include 'fragments/footer.html';
    ?>            
	
    <?php
    include 'fragments/util-bot.html';
    ?> 
	
</body>
</html>
    

