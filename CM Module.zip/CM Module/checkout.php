<?php
    session_start();
    session_destroy();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>SYLVESTER'S SALON</title>
    
    <?php
    include 'fragments/util-top.html';
    ?>
</head>
    
<body>
<?php
    include 'fragments/header.html';
    ?>
	
	<h2 align='center'>Thank you :)!!!</h2>

        <?php
    include 'fragments/footer.html';
    ?>            
	
    <?php
    include 'fragments/util-bot.html';
    ?> 
	
</body>
</html>
    